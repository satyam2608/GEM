
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Services from './pages/Services';
import Navbar from './componant/Navbar'; // Ensure the path is correct
import SubHeader from './componant/SubHeader'; // Ensure the path is correct
import Footer from './componant/Footer';

export default function App() {
  return (
    <BrowserRouter>
      <SubHeader />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        {/* Uncomment and add routes as needed */}
        {/* <Route path="/about" element={<About />} /> */}
        {/* <Route path="/contact" element={<Contact />} /> */}
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
