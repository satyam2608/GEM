export const getImageUrl = (path) => {
    return new URL(`../assets/cardImg/${path}`, import.meta.url).href;
};
