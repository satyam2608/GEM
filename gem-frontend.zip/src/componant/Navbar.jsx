
// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faBars, faXmark } from '@fortawesome/free-solid-svg-icons';
// import logo1 from '../assets/logo-img2.png';
// import logo2 from '../assets/logo-img1.png';
// import './Navbar.css';
// import Services from '../pages/Services';

// const Navbar = () => {
//     const [menuOpen, setMenuOpen] = useState(false);

//     return (
//         <nav className="navbar">
//             <div className="logo-container">
//                 <img src={logo1} alt="Logo 1" className="logo" />
//                 <img src={logo2} alt="Logo 2" className="logo" />
//             </div>

//             <div className="menu-icon" onClick={() => setMenuOpen(!menuOpen)}>
//                 <FontAwesomeIcon icon={menuOpen ? faXmark : faBars} />
//             </div>

//             <ul className={`nav-links ${menuOpen ? 'open' : ''}`}>
//                 <li><Link to="/" onClick={() => setMenuOpen(false)}>Home</Link></li>
//                 <li><Link to="/services" onClick={() => setMenuOpen(false)}>Services </Link></li>
//                 {/* Uncomment these lines if you have corresponding routes */}
//                 {/* <li><Link to="/about" onClick={() => setMenuOpen(false)}>About</Link></li> */}
//                 {/* <li><Link to="/contact" onClick={() => setMenuOpen(false)}>Contact</Link></li> */}
//             </ul>
//         </nav>
//     );
// };

// export default Navbar;



// new code

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faXmark } from '@fortawesome/free-solid-svg-icons';
import logo1 from '../assets/logo-img2.png';
import logo2 from '../assets/logo-img1.png';
import './Navbar.css';

const Navbar = () => {
    const [menuOpen, setMenuOpen] = useState(false);

    // Function to handle the closing of the menu
    const handleMenuClose = () => {
        setMenuOpen(false);
    };

    return (
        <nav className="navbar">
            <div className="logo-container">
                <img src={logo1} alt="Logo 1" className="logo" />
                <img src={logo2} alt="Logo 2" className="logo" />
            </div>

            <div
                className={`menu-icon ${menuOpen ? 'rotate' : ''}`}
                onClick={() => setMenuOpen(!menuOpen)}
            >
                <FontAwesomeIcon icon={menuOpen ? faXmark : faBars} />
            </div>

            <ul 
                className={`nav-links ${menuOpen ? 'open' : ''}`}
            >
                <li><Link to="/" >Home</Link></li>
                <li><Link to="/services" >About Us</Link></li>
                <li><Link to="/services" >GEM Green Certification</Link></li>
                <li><Link to="/services" >Sustainability Solutions</Link></li>
                <li><Link to="/services" >GEM Ecosystem</Link></li>
                <li><Link to="/services" >Certified Professionals</Link></li>
                <li><Link to="/services" >Events</Link></li>
                <li><Link to="/services" >Register For Projects</Link></li>
                <li><Link to="/services" >Resources</Link></li>
                <li></li>
                {/* Add other links if necessary */}
                {/* <li><Link to="/about" onClick={handleMenuClose}>About</Link></li> */}
                {/* <li><Link to="/contact" onClick={handleMenuClose}>Contact</Link></li> */}
            </ul>
        </nav>
    );
};

export default Navbar;
