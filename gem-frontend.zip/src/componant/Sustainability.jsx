// import React, { useState } from 'react';
// import { getImageUrl } from '../utils';

// // Repeat for other images


// import './Sustainability.css';

// const cardData = [
//     { imgSrc: 'cardImg-1.png', text: 'GEM Green Building Certification' },
//     { imgSrc: 'path/to/image2.jpg', text: 'GEM Eco-Product Certification' },
//     { imgSrc: 'path/to/image3.jpg', text: 'Carbon Footprinting' },
//     { imgSrc: 'path/to/image4.jpg', text: 'Sustainability Assessment' },
//     { imgSrc: 'path/to/image5.jpg', text: 'Criteria VII (Environmental parameters) of NAAC' },
//     { imgSrc: 'path/to/image6.jpg', text: 'ISO 14001 conformity' },
//     { imgSrc: 'path/to/image7.jpg', text: 'Environmental Management Plans' },
//     { imgSrc: 'path/to/image8.jpg', text: 'Water Audits' },
//     { imgSrc: 'path/to/image9.jpg', text: 'Energy Audits' },
// ];

// const Sustainability = () => {
//     const [formData, setFormData] = useState({
//         project: '',
//         firstName: '',
//         lastName: '',
//         email: '',
//     });

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({
//             ...formData,
//             [name]: value,
//         });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         localStorage.setItem('formData', JSON.stringify(formData));
//         alert('Form data saved to local storage!');
//         console.log(formData);
//     };

//     return (
//         <div className="sustainability-container">
//             <div className="cards-container">
//                 {cardData.map((card, index) => (
//                     <div key={index} className="card">
//                         <div className="card-img">
//                             <img src={getImageUrl(card.imgSrc)} alt={`Sustainability Goal ${index + 1}`} />
//                         </div>
//                         <div className="card-text">
//                             {card.text}
//                         </div>
//                     </div>
//                 ))}
//             </div>
//             <div className="form-container">
//                 <h2>GEM Certification Enquiry</h2>
//                 <form onSubmit={handleSubmit}>
//                     <label>
//                         Select Project:
//                         <select name="project" value={formData.project} onChange={handleChange}>
//                             <option value="">Select a project</option>
//                             <option value="project1">Project 1</option>
//                             <option value="project2">Project 2</option>
//                             <option value="project3">Project 3</option>
//                         </select>
//                     </label>
//                     <label>
//                         First Name:
//                         <input
//                             type="text"
//                             name="firstName"
//                             value={formData.firstName}
//                             onChange={handleChange}
//                             required
//                         />
//                     </label>
//                     <label>
//                         Last Name:
//                         <input
//                             type="text"
//                             name="lastName"
//                             value={formData.lastName}
//                             onChange={handleChange}
//                             required
//                         />
//                     </label>
//                     <label>
//                         Email:
//                         <input
//                             type="email"
//                             name="email"
//                             value={formData.email}
//                             onChange={handleChange}
//                             required
//                         />
//                     </label>
//                     <button type="submit">Submit</button>
//                     <h3>Certification fee provided here is tentative</h3>
//                 </form>
//             </div>
//         </div>
//     );
// };

// export default Sustainability;

import React, { useState } from 'react';
import './Sustainability.css';

// Your card data
const cardData = [
    { imgSrc: 'cardImg/cardImg-1.png', text: 'GEM Green Building Certification' },
    { imgSrc: 'cardImg/cardImg-2.png', text: 'GEM Eco-Product Certification' },
    { imgSrc: 'cardImg/cardImg-3.png', text: 'Carbon Footprinting' },
    { imgSrc: 'cardImg/cardImg-4.png', text: 'Sustainability Assessment' },
    { imgSrc: 'cardImg/cardImg-5.png', text: 'Criteria VII (Environmental parameters) of NAAC' },
    { imgSrc: 'cardImg/cardImg-6.png', text: 'ISO 14001 conformity' },
    { imgSrc: 'cardImg/cardImg-7.png', text: 'Environmental Management Plans' },
    { imgSrc: 'cardImg/cardImg-8.png', text: 'Water Audits' },
    { imgSrc: 'cardImg/cardImg-9.png', text: 'Energy Audits' },
];

const Sustainability = () => {
    const [formData, setFormData] = useState({
        project: '',
        firstName: '',
        lastName: '',
        email: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        localStorage.setItem('formData', JSON.stringify(formData));
        alert('Form data saved to local storage!');
        console.log(formData);
    };

    return (
        <div className="sustainability-container">
            <div className="cards-container">
                {cardData.map((card, index) => (
                    <div key={index} className="card">
                        <div className="card-img">
                            <img src={require(`../assets/${card.imgSrc}`)} alt={`Sustainability Goal ${index + 1}`} />
                        </div>
                        <div className="card-text">
                            {card.text}
                        </div>
                    </div>
                ))}
            </div>
            <div className="form-container">
                <h2>GEM Certification Enquiry</h2>
                <form onSubmit={handleSubmit}>
                    <label>
                        Select Project:
                        <select name="project" value={formData.project} onChange={handleChange}>
                            <option value="">Select a project</option>
                            <option value="project1">Project 1</option>
                            <option value="project2">Project 2</option>
                            <option value="project3">Project 3</option>
                        </select>
                    </label>
                    <label>
                        First Name:
                        <input
                            type="text"
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Last Name:
                        <input
                            type="text"
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Email:
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <button type="submit">Submit</button>
                    <h3>Certification fee provided here is tentative</h3>
                </form>
            </div>
        </div>
    );
};

export default Sustainability;
