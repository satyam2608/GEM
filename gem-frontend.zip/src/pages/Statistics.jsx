import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUsers, faBriefcase, faCertificate, faRocket, faUniversity, faHandshake, faBookOpen } from '@fortawesome/free-solid-svg-icons';
import './Statistics.css'; // Import the CSS file

const Statistics = () => {
    return (
        <div className="statistics-container">
            <div className="stat-item">
                <FontAwesomeIcon icon={faUsers} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">150,000+</span>
                    <span className="stat-label">Participants</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faBriefcase} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">2,000+</span>
                    <span className="stat-label">Professional</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faCertificate} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">1,500+</span>
                    <span className="stat-label">Certified Professional</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faRocket} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">200+</span>
                    <span className="stat-label">Conference & Webinar</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faUniversity} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">100+</span>
                    <span className="stat-label">Institutional MOU</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faBookOpen} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">30+</span>
                    <span className="stat-label">Knowledge Consulting Partners</span>
                </div>
            </div>
            <div className="stat-item">
                <FontAwesomeIcon icon={faHandshake} className="stat-icon" />
                <div className="stat-text">
                    <span className="stat-number">10+</span>
                    <span className="stat-label">Professional MOU</span>
                </div>
            </div>
        </div>
    );
};

export default Statistics;
