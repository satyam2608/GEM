// import React from 'react'
// import logo1 from '../assets/logo2.png'; // Adjust path as needed
// import logo2 from '../assets/logo1.png'; // Adjust path as needed
// import './Navbar.css';

// const Header = () => {
//     const [isOpen, setIsOpen] = useState(false);

//   const toggleMenu = () => setIsOpen(!isOpen);
//   return (
//     <>
//       <nav className="navbar">
//       <div className="logo-container">
//         <img src={logo1} alt="Logo 1" className="logo" />
//         <img src={logo2} alt="Logo 2" className="logo" />
//       </div>
//       <div className={`hamburger ${isOpen ? 'open' : ''}`} onClick={toggleMenu}>
//         <div className="bar"></div>
//         <div className="bar"></div>
//         <div className="bar"></div>
//       </div>
//       <ul className={`nav-links ${isOpen ? 'open' : ''}`}>
//         <li><a href="#home">Home</a></li>
//         <li><a href="#services">Services</a></li>
//         <li><a href="#about">About</a></li>
//         <li><a href="#contact">Contact</a></li>
//       </ul>
//     </nav>
//     </>
//   )
// }

// export default Header


import React, { useState } from 'react'; // Import useState
import { Link } from 'react-router-dom'; // Import Link for routing
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'; // Import FontAwesomeIcon
import { faBars, faXmark } from '@fortawesome/free-solid-svg-icons'; // Import specific icons
import logo1 from '../assets/logo-img2.png'; // Correct path
import logo2 from '../assets/logo-img1.png'; // Correct path
import './Navbar.css'; // Ensure CSS file is correctly named and located

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleMenu = () => setIsOpen(!isOpen);

    return (
        <nav className="navbar">
            <div className="logo-container">
                <img src={logo1} alt="Logo 1" className="logo" />
                <img src={logo2} alt="Logo 2" className="logo" />
            </div>

            <div className="menu-icon" onClick={toggleMenu}>
                <FontAwesomeIcon icon={isOpen ? faXmark : faBars} />
            </div>

            <ul className={`nav-links ${isOpen ? 'open' : ''}`}>
                <li><Link to="/" onClick={() => setIsOpen(false)}>Home</Link></li>
                <li><Link to="/services" onClick={() => setIsOpen(false)}>Services</Link></li>
                {/* Uncomment these lines if you add corresponding routes */}
                {/* <li><Link to="/about" onClick={() => setIsOpen(false)}>About</Link></li> */}
                {/* <li><Link to="/contact" onClick={() => setIsOpen(false)}>Contact</Link></li> */}
            </ul>
        </nav>
    );
}

export default Navbar;
