
import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import SubHeader from './componant/SubHeader';
import Home from './componant/Home';
import Services from './componant/Services';
import Navbar from './componant/Navbar';


function App() {
  return (
   <>
   <SubHeader />
    
   <Router>
      <div>
        <Navbar />
        
          <Route path="/" exact component={Home} />
          <Route path="/services" component={Services} /> 
          
      </div>
    </Router>

   </>
  );
}



export default App;
